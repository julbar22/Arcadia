﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class Folder : Element
    {
        public string name { get; set; }
        public string[] keywords { get; set; }
        public string folderFatherId { get; set; }       
        public string lastEdit { get; set; }        
        public bool visibilityFlag { get; set; }
        

        public Folder()
        {

        }
    }
}
