﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class AttributeModel : Element
    {
        public string v { get; set; }
        public float active { get; set; }
        public string name { get; set; }
        public string sensorName { get; set; }
        public string sensorGroup { get; set; }
        public string sensorProviderCode { get; set; }
        public string shortDescription { get; set; }
        public string description { get; set; }
        public string status { get; set; }
        public string notificationTimeStamp { get; set; }
        public string measurementDescription { get; set; }
        public string measurementUnit { get; set; }
        public float opreationalRangeGreen { get; set; }
        public float opreationalRangeYellow { get; set; }
        public float baseLineMin { get; set; }
        public float baseLineMax { get; set; }
        public float standardValueMin { get; set; }
        public float standardValueMax { get; set; }
        public float currentValue { get; set; }
        public string currentDate { get; set; }
        public string entityId { get; set; }
        public bool isTacometer { get; set; }
        public bool isThermometer { get; set; }

        public AttributeModel()
        {

        }
    }
    
}
