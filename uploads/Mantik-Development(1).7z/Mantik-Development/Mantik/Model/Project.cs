﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Mantik.Model
{
    public class Project : Element
    {
        public string v { get; set; }
        public string active { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string longitude { get; set; }
        public string latitude { get; set; }
        public string pole { get; set; }
        public string normalSprite { get; set; }
        public string hoverSprite { get; set; }
        public string ativeSprite { get; set; }
        public string normalColor_r { get; set; }
        public string normalColor_g { get; set; }
        public string normalColor_b { get; set; }
        public string normalColor_a { get; set; }
        public string normalPixelInset_x { get; set; }
        public string normalPixelInset_y { get; set; }
        public string normalPixelInset_w { get; set; }
        public string normalPixelInset_h { get; set; }
        public string textShow { get; set; }
        public string textPixelInset_x { get; set; }
        public string textPixelInset_y { get; set; }
        public string textFontSize { get; set; }
        public string textColor_r { get; set; }
        public string textColor_g { get; set; }
        public string textColor_b { get; set; }
        public string textColor_a { get; set; }        
        public string textAlignment { get; set; }
        public string[] systems { get; set; }
        public string photo { get; set; }
        public string companyId { get; set; }

        public Project()
        {

        }
    }
}
