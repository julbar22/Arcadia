﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Mantik.Model
{
    public class EntitiesHierarchy : Element
    {
        public string hierarchyName { get; set; }
        public string hierarchyHead { get; set; }
        public string[] hierarchyUsers { get; set; }
        public string[] hierarchyMembers { get; set; }   
        public int active { get; set; }

        public EntitiesHierarchy()
        {

        }
    }
  }
