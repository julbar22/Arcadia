﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class DocumentsCategory : Element
    {
        public string name { get; set; }
        public string[] keywords { get; set; }
        public string description { get; set; }        

        public DocumentsCategory()
        {

        }
    }
}
