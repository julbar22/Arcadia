﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Mantik.Model
{
    public class Entity : Element
    {
        public string v { get; set; }
        public string description { get; set; }
        //public string[] eAncestors { get; set; }
        //public string eParent { get; set; }
        public string eType { get; set; }
        //public string entityFather { get; set; }
        public string idUser { get; set; }
        public string instalationDate { get; set; }
        public string name { get; set; }
        public string serialNumber { get; set; }
        public string type { get; set; }
        //public string[] subEntity { get; set; }
        public string[] attributes { get; set; }
        public string[] status { get; set; }
        public string company { get; set; }
        public string emailDirector { get; set; }
        public string itemLocation { get; set; }
        public string nameDirector { get; set; }
        public Rotation rotation { get; set; }
        public Location location { get; set; }
        public string prefabScene { get; set; }
        public int active { get; set; }
        public Entity()
        {

        }
    }
  }
