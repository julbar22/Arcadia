﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class User : Element
    {
        public string user { get; set; }
        public string password { get; set; }
        public string name { get; set; }
        public string typeUser { get; set; }
        public int projectID { get; set; }
        public string token { get; set; }
    }
}
