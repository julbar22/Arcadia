﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class AttributeCategories : Element
    {
        public string name { get; set; }
        public float standardValueMax { get; set; }
        public float currentValue { get; set; }
        public string measurementUnit { get; set; }
        public string description { get; set; }
        public string status { get; set; }

        public AttributeCategories()
        {

        }
    }
}
