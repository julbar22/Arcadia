﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Mantik.Model
{
    public class EntitiesRelationship : Element
    {
        public string memberType { get; set; }
        public string memberId { get; set; }     
        public string[] entitySons { get; set; }
        public string[] entityFather { get; set; }
        public string depthLevelName { get; set; }

        public EntitiesRelationship()
        {

        }
    }
  }
