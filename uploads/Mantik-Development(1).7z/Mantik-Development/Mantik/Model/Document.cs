﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class Document : Element
    {
        public string name { get; set; }
        public string[] keywords { get; set; }
        public string folderFatherId { get; set; }        
        public bool visibilityFlag { get; set; }
        public float currentVersion { get; set; }
        public string url { get; set; }
        public string type { get; set; }
        public string source { get; set; }
        public string extension { get; set; }

        public Document()
        {

        }
    }
}
