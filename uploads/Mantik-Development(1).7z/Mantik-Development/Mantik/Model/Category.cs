﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class Category : Element
    {
        public string description { get; set; }
        public string name { get; set; }
        public string sensorName { get; set; }
        public string standardValueMax { get; set; }
        public string standardValueMin { get; set; }
        public string baseLineMin { get; set; }
        public string baseLineMax { get; set; }
        public string currentValue { get; set; }
        public string measurementUnit { get; set; }
        public string status { get; set; }
        public string Att_type { get; set; }
        public string type { get; set; }
        public bool isTacometer { get; set; }
        public bool isThermometer { get; set; }

        public Category()
        {

        }
    }
}
