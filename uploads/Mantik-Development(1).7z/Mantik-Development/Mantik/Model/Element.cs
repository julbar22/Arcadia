﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class Element
    {
        public string _id { get; set; }

        public Element()
        {

        }

    }
}
