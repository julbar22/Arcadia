﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class Report : Element
    {
        public string Ent_id { get; set; }
        public string Rep_number { get; set; }
        public string Rep_name { get; set; }
        public string Rep_url { get; set; }
        public string v { get; set; }

        public Report()
        {

        }
    }
}
