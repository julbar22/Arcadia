﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Model
{
    public class Notification : Element
    {
        public string id { get; set; }
        public string message { get; set; }
        public string ack { get; set; }
        public string type { get; set; }

        public Info info { get; set; }
    }

    public class Info
    {
        public float maintenanceState { get; set; }
        public float idMaintenance { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public double date { get; set; }
        public string state { get; set; }
        public string subSystem { get; set; }
        public string system { get; set; }
        public string typeEntity { get; set; }
        public float idEntity { get; set; }
    }
}
