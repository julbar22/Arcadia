﻿using Mantik.Handler;
using Mantik.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Mantik.Logic.Dashboard
{
    public class Dashboard
    {
        private CustomerDataHandler handler;
        private EntityHandler entityHandler;
        

        public Dashboard()
        {
            handler = new CustomerDataHandler();
            entityHandler = new EntityHandler();
        }

        public Category[] GetCategoryDashboard()
        {
            return handler.getCategories();
        }

        public AttributeCategories[] GetAttributeCategoriesDashboard(string id)
        {
            return handler.getAttributeCategories(id);
        }

        public Category[] GetAttributes(string id)
        {
            return handler.getAttributes(id);
        }

        public Element GetCostumerDataEntities(string id)
        {
            return entityHandler.getByID(id);
        }
    }
}