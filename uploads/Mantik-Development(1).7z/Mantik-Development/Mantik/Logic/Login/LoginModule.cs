﻿using Mantik.Handler;
using Mantik.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Logic.Login
{
    public class LoginModule
    {
        private LoginHandler loginHandler;

        public LoginModule()
        {
            loginHandler = new LoginHandler();
        }

        public bool initSession(string user, string password, ref Session session)
        {
            User userResquest;
            ModuleHandler modules = new ModuleHandler();
            try
            {
                userResquest = (User)loginHandler.loginRequest(user, password);

                if (userResquest != null)
                {
                    if (session != null)
                    {
                        session.user = userResquest;
                        session.modules = modules.getModulesByIDUser(1);
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
