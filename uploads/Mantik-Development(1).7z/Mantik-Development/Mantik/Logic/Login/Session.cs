﻿using Mantik.Handler;
using Mantik.Model;
using System.Collections.Generic;

namespace Mantik.Logic.Login
{
    public class Session
    {
        private string userName;
        public User user { get; set; }
        public List<Module> modules { get; set; }

        // private string directorScene;


        public Session(string user)
        {
            this.userName = user;
        }
    }
}