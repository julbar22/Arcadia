﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Logic.Login
{
    public class Menu
    {
        public string name { get; set; }
        public List<Menu> sons { get; set; }

        public Menu(string name)
        {
            this.name = name;
        }

        public Menu(string name, List<Menu> menus)
        {
            this.name = name;
            this.sons = menus;
        }

        public void addMenu(Menu menu)
        {
            sons.Add(menu);
        }
    }
}
