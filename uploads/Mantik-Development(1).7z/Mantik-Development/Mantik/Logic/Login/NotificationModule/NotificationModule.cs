﻿using Mantik.Handler;
using Mantik.Model;
using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;

namespace Mantik.Logic.NotificationModule
{
    public class NotificationModule
    {
        NotificationHandler notificationHandler;
        public NotificationModule()
        {
            notificationHandler = new NotificationHandler();
        }

        public List<Notification> getAllNotifications(string userId)
        {
            return notificationHandler.getAllByUserId(userId);
        }

        public List<Notification> getNotificationsByACK(string userId, string[] acks)
        {
            //List<Notification> newList =  notificationHandler.getAllByUserId(userId).ConvertAll<Notification>(delegate(Element item) { return (Notification)item; });
            List<Notification> notifications = notificationHandler.getAllByUserId(userId);
            List<Notification> notificationsByACK = new List<Notification>();
            foreach (Notification oneNotif in notifications)
            {
                if (-1 != Array.IndexOf(acks, oneNotif.ack))
                {
                    notificationsByACK.Add(oneNotif);
                }
            }
            return notificationsByACK;
        }

        public List<Notification> getNotificationsByType(string userId, string type)
        {
            try
            {
                return notificationHandler.getAllByUserId(userId).FindAll(n => n.type == type);
            }
            catch (NullReferenceException ex)
            {
                System.Console.WriteLine(ex);
                return new List<Notification>();
            }
        }

        public List<Notification> sortedByDate(List<Notification> notifications)
        {
            try
            {
                return notifications.OrderBy(n => n.info.date).ToList(); 
            }
            catch (NullReferenceException ex)
            {
                System.Console.WriteLine(ex);
                return new List<Notification>();
            }
            
        }

        public List<Notification> sortedByState(List<Notification> notifications)
        {
            try
            {
                return notifications.OrderBy(n =>
                {
                    if (n.info.state == "red") { return 1; }
                    else if (n.info.state == "orange") { return 2; }
                    else if (n.info.state == "yellow") { return 3; }
                    else if (n.info.state == "green") { return 4; }
                    else if (n.info.state == "blue") { return 5; }
                    else { return 0; }
                }).ToList();
            }
            catch (NullReferenceException ex)
            {
                System.Console.WriteLine(ex);
                return new List<Notification>();
            }
           
        }

        public List<Notification> sortedByTypeMaintenance(List<Notification> notifications)
        {
            try
            {
                return notifications.FindAll(n => n.type == "maintenance");
            }
            catch (NullReferenceException ex)
            {
                System.Console.WriteLine(ex);
                return new List<Notification>();
            }
        }

        public List<Notification> sortedByTypeService(List<Notification> notifications)
        {
            try
            {
                return notifications.FindAll(n => n.type == "serviceRequest");
            }
            catch (NullReferenceException ex)
            {
                System.Console.WriteLine(ex);
                return new List<Notification>();
            }
        }

        public List<Notification> sortedByTypeServiceRequestGenerated(List<Notification> notifications)
        {
            try
            {
                return notifications.FindAll(n => n.type == "serviceRequestGenerated");
            }
            catch (NullReferenceException ex)
            {
                System.Console.WriteLine(ex);
                return new List<Notification>();
            }
        }
        public Notification changeACK(Notification notification)
        {
            Debug.Log("ack en mantik"+ notification.ack);
            Debug.Log("id en mantik" + notification.id);
            return notificationHandler.postChangeACK(notification.id, notification);
        }
    }
}
