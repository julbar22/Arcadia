﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Logic.Login
{
    public class Module
    {
        public string name { get; set; }
        public bool isMenu { get; set; }
        public List<Menu> menus { get; set; }
        public string panelUbication { get; set; }

        public Module(string name, bool isMenu, string panelUbication, List<Menu> menu)
        {
            this.name = name;
            this.isMenu = isMenu;
            this.panelUbication = panelUbication;
            this.menus = menu;
        }

        public Module(string name, bool isMenu, string panelUbication)
        {
            this.name = name;
            this.isMenu = isMenu;
            this.panelUbication = panelUbication;
        }
    }
}