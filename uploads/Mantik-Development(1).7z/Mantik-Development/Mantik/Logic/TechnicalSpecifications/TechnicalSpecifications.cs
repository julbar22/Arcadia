﻿using Mantik.Handler;
using Mantik.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Mantik.Logic.Dashboard
{
    public class TechnicalSpecifications
    {
        private TechnicalSpecificationsHandler TSHandler;

        public TechnicalSpecifications()
        {
            TSHandler = new TechnicalSpecificationsHandler();
        }

        public Dictionary<string, string> getTechnicalSpecifications(string id)
        {
            Dictionary<string, string> info = new Dictionary<string, string>();
           
            foreach (KeyValuePair<string, object> inf in TSHandler.getByEntityID(id))
            {
                if (inf.Value != null)
                {
                    info.Add(inf.Key, inf.Value.ToString());
                }
                else
                {
                    info.Add(inf.Key, "null");
                }
            }
            return info;
        }
    }
}
    