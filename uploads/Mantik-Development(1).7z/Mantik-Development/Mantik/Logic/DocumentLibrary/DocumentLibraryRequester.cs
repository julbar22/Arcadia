﻿using Mantik.Handler;
using Mantik.Model;
using System.Collections.Generic;

using UnityEngine;
using Mantik.Logic.DocumentLibrary.ReferenceConstants;

namespace Mantik.Logic.DocumentLibrary
{
    public class DocumentLibraryRequester
    {
        EntityHandler entityHandler;
        ProjectHandler projectHandler;
        AttributeHandler attributeHandler;
        DocumentsCategoryHandler categoryHandler;
        DocumentHandler documentHandler;
        FolderHandler folderHandler;

        public DocumentLibraryRequester()
        {
            entityHandler = new EntityHandler();
            projectHandler = new ProjectHandler();
            attributeHandler = new AttributeHandler();
            categoryHandler = new DocumentsCategoryHandler();
            documentHandler = new DocumentHandler();
            folderHandler = new FolderHandler();
        }


        public List<DocumentationElement> findLevelSons(DocumentationElement father, int contentType)
        {
            List<DocumentationElement> sons = new List<DocumentationElement>();
            bool pass = true;
            switch (contentType)
            {
                case DrawingTypes.containers:
                    pass = true;
                    switch (father.type)
                    {                        
                        // Concrete cases
                        case ConcreteReferenceTypes.project:
                            foreach (Element entity in entityHandler.getSonsByEntityFatherId(father.id, true))
                               
                                {
                                sons.Add(new DocumentationElement(entity));
                            }
                            break;
                        case ConcreteReferenceTypes.system:
                        case ConcreteReferenceTypes.subSystem:
                        case ConcreteReferenceTypes.objectElement:
                            foreach (Element entity in entityHandler.getSonsByEntityFatherId(father.id, false))
                            {
                                sons.Add(new DocumentationElement(entity));
                            }
                            break;
                        default:
                            pass = false;
                            break;
                    }

                    if (!pass)
                    {
                        Debug.LogError("Not implemented yet in findLevelSons() [DocumentLibrary- Mantik]");
                    }

                    Dictionary<string, int> contentContainers = getContainerFolders(father);                                       
                    foreach (string element in contentContainers.Keys)
                    {
                        DocumentationElement son = new DocumentationElement();                        
                        son.name = element;
                        son.sonsType = contentContainers[element];
                        son.type = ConcreteReferenceTypes.container;
                        if (element == "Other")
                        {
                            if (categoryHandler.getByEntityIdAndType(father.id, getFlagEntityType(father.type)).Length == 0)     
                                son.enabled = false;                            
                        }
                        sons.Add(son);
                    }
                    break;
                case DrawingTypes.entities:
                case DrawingTypes.projects:                                

                    switch (father.type)
                    {
                        // General cases
                        case GeneralReferenceTypes.projects:
                            foreach (Element project in projectHandler.findAll())
                            {
                                sons.Add(new DocumentationElement(project));
                            }                            
                            break;
                        case GeneralReferenceTypes.systems:
                        case GeneralReferenceTypes.subSystems:
                        case GeneralReferenceTypes.objects:                            
                            pass = false;
                            break;                        
                        default:
                            pass = false;
                            break;
                    }

                    if (!pass)
                    {
                        Debug.LogError("Not implemented yet in findLevelSons() [DocumentLibrary- Mantik]");
                    }
                    break;
                case DrawingTypes.sensors:                    
                    foreach (Element sensor in attributeHandler.getAttributesByEntityId(father.id))
                    {
                        sons.Add(new DocumentationElement(sensor));
                    }
                    break;
                default:
                    Debug.LogError("Wrong contentType flag in findLevelSons() [DocumentLibrary- Mantik]");
                    sons = null;
                    break;
            }
            return sons;
        }        

        public List<DocumentationElement> getDocumentsForEntity(DocumentationElement father, DocumentationElement folderFather)
        {
            if (father != null)
            {                
                string flagEntityType = "";               

                string entityType = father.type; 
                string idEntity = father.id;
                flagEntityType = getFlagEntityType(entityType);

                if (folderFather == null)
                {
                    List<DocumentationElement> categories = new List<DocumentationElement>();
                    foreach (Element category in categoryHandler.getByEntityIdAndType(idEntity, flagEntityType))
                    {
                        categories.Add(new DocumentationElement(category));
                    }
                    return categories;               
                }
                else
                {
                    string folderType = folderFather.type;
                    string idFolder = folderFather.id;
                    List<DocumentationElement> folders = null;
                    List<DocumentationElement> files = null;
                    Element[] tempFiles = null;
                    Element[] tempFolders = null;

                    if ( (folderType == ConcreteReferenceTypes.folderCategory && idFolder == "0") || folderType == ConcreteReferenceTypes.folder)
                    {
                        tempFolders = folderHandler.getByFolderFatherIdAndEnityId(idFolder, idEntity, flagEntityType);
                        tempFiles = documentHandler.getByFolderFatherIdAndEntityId(idFolder, idEntity, flagEntityType);
                    }

                    else if (folderType == ConcreteReferenceTypes.folderCategory)
                    {
                        tempFiles = documentHandler.getDocumentsByCategoryIdAndEntityId(idFolder, idEntity, flagEntityType);
                    }

                    if (tempFolders != null)
                    {
                        folders = new List<DocumentationElement>();
                        foreach (Element folder in tempFolders)
                        {
                            folders.Add(new DocumentationElement(folder));
                        }
                    }

                    if (tempFiles != null)
                    {
                        files = new List<DocumentationElement>();
                        foreach (Element file in tempFiles)
                        {
                            files.Add(new DocumentationElement(file));
                        }
                    }
                    

                    List<DocumentationElement> documentsList;

                    if (folders != null && files != null)
                    {
                        documentsList = new List<DocumentationElement>(files.Count + folders.Count);
                        //foreach (DocumentationElement folder in folders)
                        //{
                        //    documentsList.Add(folder);
                        //}

                        //foreach (DocumentationElement file in files)
                        //{
                        //    documentsList.Add(file);
                        //}

                        documentsList.AddRange(folders);
                        documentsList.AddRange(files);
                    }

                    else if (folders != null)
                    {
                        documentsList = folders;
                    }
                    else
                    {
                        documentsList = files;
                    }
                    return documentsList;
                }                
            }
            return null;
        }

        private Dictionary<string, int> getContainerFolders(DocumentationElement father)
        {
            Dictionary<string, int> content = new Dictionary<string, int>();
            if (father != null)
            {
                //if (father.type != null)
                //{
                //    if (father.type != ConcreteReferenceTypes.project && father.type != ConcreteReferenceTypes.sensor)
                //    {
                //        content["Sensors"] = DrawingTypes.sensors;
                //    }
                //}
                content["Other"] = DrawingTypes.documents;
            }
            return content;
        }

        private string getFlagEntityType(string elementType)
        {
            string response = "";
            switch (elementType)
            {
                case ConcreteReferenceTypes.project:
                    response = "1";
                    break;
                case ConcreteReferenceTypes.system:
                case ConcreteReferenceTypes.subSystem:
                case ConcreteReferenceTypes.objectElement:
                    response = "2";
                    break;
                case ConcreteReferenceTypes.sensor:
                    response = "3";
                    break;
            }
            return response;
        }

        public string getFileURLByDocument(DocumentationElement file)
        {
            if (file.type == ConcreteReferenceTypes.file)
            {
                return documentHandler.getUrlByDocumentId(file.id);
            }   
            return null;
        }
    }
    
}