﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mantik.Model;
using Mantik.Logic.DocumentLibrary.ReferenceConstants;

namespace Mantik.Logic.DocumentLibrary
{
    public class DocumentationElement
    {
        public string id { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public int sonsType { get; set; }
        public bool enabled { get; set; }

        public DocumentationElement()
        {
            id = null;
            name = null;
            type = null;
            enabled = true;
            sonsType = int.MinValue;          
        }

        public DocumentationElement (Element element)
        {
            if (element != null)
            {
                id = element._id;
                enabled = true;
                sonsType = DrawingTypes.containers;                
                if (element is Entity)
                {
                    Entity temp = (Entity)element;                    
                    name = temp.name;
                    type = temp.type;                    
                }
                else if (element is Project)
                {
                    Project temp = (Project)element;
                    name = temp.name;
                    type = ConcreteReferenceTypes.project;                  
                }
                else if (element is AttributeModel)
                {
                    AttributeModel temp = (AttributeModel)element;
                    name = temp.name;
                    type = ConcreteReferenceTypes.sensor;
                }
                else if (element is DocumentsCategory)
                {
                    DocumentsCategory temp = (DocumentsCategory)element;
                    name = temp.name;
                    type = ConcreteReferenceTypes.folderCategory;
                }
                else if (element is Document)
                {
                    Document temp = (Document)element;
                    name = temp.name;
                    type = ConcreteReferenceTypes.file;
                }

                else if (element is Folder)
                {
                    Folder temp = (Folder)element;
                    name = temp.name;
                    type = ConcreteReferenceTypes.folder;
                }

                else
                {
                    name = null;
                    type = null;
                }
            }        

        }        
    }
}
