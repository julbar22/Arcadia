﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Logic.DocumentLibrary.ReferenceConstants
{
    public static class GeneralReferenceTypes
    {
        public const string projects = "projects";
        public const string systems = "systems";
        public const string subSystems = "subSystems";
        public const string objects = "objects";
        public const string sensors = "sensors";
    }
}
