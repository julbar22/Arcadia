﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Logic.DocumentLibrary.ReferenceConstants
{
    public static class DrawingTypes
    {
        //Not drawing
        public const int notDrawing = -1;
        // Drawing data of scene [It is not necessary to update].
        public const int drawingDataInScene = 0;
        //It refers to the view of projects of one group (Projects, systems, subsystems and objects) [It should be update].
        public const int projects = 1;
        //It refers to view of folders which classifies the content of a particular entity [It is not necessary to update].
        public const int containers = 2;
        //It refers to the view of entities of one group (Projects, systems, subsystems and objects) [It should be update].
        public const int entities = 3;
        //It refers to the view of sensors of one entity (attributes) [It should be update].
        public const int sensors = 4;
        //It refers to the view of documents (folders and files) of one project, entity or sensor [It should be update].
        public const int documents = 5;
    }
}
