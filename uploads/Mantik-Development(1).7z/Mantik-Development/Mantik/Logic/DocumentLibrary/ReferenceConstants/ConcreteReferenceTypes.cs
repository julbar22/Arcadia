﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Logic.DocumentLibrary.ReferenceConstants
{
    public static class ConcreteReferenceTypes
    {
        public const string project = "project";
        public const string system = "system";
        public const string subSystem = "subSystem";
        public const string objectElement = "object";
        public const string sensor = "sensor";
        public const string folder = "folder";
        public const string folderCategory = "folderCategory";
        public const string file = "file";
        public const string container = "container";
    }
}
