﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mantik.Model;
using Mantik.Logic.DocumentLibrary.ReferenceConstants;

namespace Mantik.Logic.SceneInitializer
{
    public class SceneElement
    {
        public string id { get; set; }
        public string name { get; set; }
        public string type { get; set; }     
        public string folderSet { get; set; }

        public SceneElement()
        {
            id = null;
            name = null;
            type = null;
            folderSet = null;       
        }

        public SceneElement(Element element)
        {
            if (element != null)
            {
                id = element._id;                            
                if (element is Entity)
                {
                    Entity temp = (Entity)element;
                    name = temp.name;
                    type = temp.type;
                }
                else if (element is Project)
                {
                    Project temp = (Project)element;
                    name = temp.name;
                    type = ConcreteReferenceTypes.project;
                }
                else if (element is AttributeModel)
                {
                    AttributeModel temp = (AttributeModel)element;
                    name = temp.name;
                    type = ConcreteReferenceTypes.sensor;
                }
                else
                {
                    name = null;
                    type = null;
                }
            }        

        }
    }
}
