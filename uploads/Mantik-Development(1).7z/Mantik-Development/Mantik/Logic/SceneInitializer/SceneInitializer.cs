﻿using Mantik.Handler;
using Mantik.Model;
using System.Collections.Generic;

using UnityEngine;
using Mantik.Logic.DocumentLibrary.ReferenceConstants;


namespace Mantik.Logic.SceneInitializer
{
    public class SceneInitializer
    {
        EntityHandler entityHandler;
        ProjectHandler projectHandler;
        AttributeHandler attributeHandler;        

        public SceneInitializer()
        {
            entityHandler = new EntityHandler();
            projectHandler = new ProjectHandler();
            attributeHandler = new AttributeHandler();                      
        }


        public SceneElement getRequestedComponent(string id, string type)
        {
            SceneElement response = new SceneElement();
            switch (type)
            {
                case ConcreteReferenceTypes.project:
                    response = new SceneElement(projectHandler.getByID(id));                    
                    break;
                case ConcreteReferenceTypes.system:
                case ConcreteReferenceTypes.subSystem:
                case ConcreteReferenceTypes.objectElement:
                    response = new SceneElement(entityHandler.getByID(id));                    
                    break;
                case ConcreteReferenceTypes.sensor:
                    response = new SceneElement(attributeHandler.getByID(id));
                    break;
                default:
                    response = null;
                    break;
            }
            return response;
        }
    }    
}