﻿using Mantik.Handler;
using Mantik.Model;
using Mantik.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Mantik.Logic.QRModule
{
    public class QRModule
    {
        private EntityHandler entityHandler;
        private QRUtil qrUtil;

        public QRModule()
        {
            entityHandler = new EntityHandler();
        }

        public Entity getEntityByQr(sbyte[] dArrayBytes, int width, int height)
        {
            Entity entity = null;
            qrUtil = QRUtil.getInstance();
            string qrString = qrUtil.DecodeQR(dArrayBytes, width, height);

            try
            {
                //if (qrString.IndexOf("3Dves") != -1)
                //{
                //    qrString = qrString.Replace("3Dves", "");
                    entity = (Entity)entityHandler.getByID(qrString);
                //}
                //else
                //{
                //    return null;
                //}
            }
            catch (Exception e)
            {
                throw new Exception(e.Message + " in " + e.InnerException);
            }
            return entity;
        }

        public List<Entity> getEntityByString(string stringCode)
        {
            List<Entity> entity = new List<Entity>();
            try
            {
                entity = entityHandler.getByName(stringCode);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message + " in " + e.InnerException);
            }
            return entity;
        }
        public Entity[] getAllEntity()
        {
            Entity[] entity;
            try
            {
                entity = (Entity[])entityHandler.findAll();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message + " in " + e.InnerException);
            }
            return entity;
        }
    }
}
