﻿using Mantik.Handler;
using Mantik.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Logic.ReportModule
{
    public class ReportModule
    {
        private ReportHandler handler;

        public ReportModule()
        {
            handler = new ReportHandler();
        }

        public int getReportNum(string idEntity)
        {
            return handler.getAllReportByEntity(idEntity).Count();

        }

        public Report[] getReportsByEntity(string idEntity)
        {
            return handler.getAllReportByEntity(idEntity);
        }
    }
}
