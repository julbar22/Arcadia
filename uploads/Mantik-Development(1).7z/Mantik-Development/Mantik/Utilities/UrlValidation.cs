﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace Mantik.Utilities
{
    public class UrlValidation
    {
        public bool UrlIsValid(string url)
        {
            try
            {
                HttpWebRequest Wrequest = HttpWebRequest.Create(url) as HttpWebRequest;
                Wrequest.Timeout = 5000;
                Wrequest.Method = "HEAD";

                HttpWebResponse Wresponse = Wrequest.GetResponse() as HttpWebResponse;

                int statusCode = (int)Wresponse.StatusCode;
                if (statusCode >= 100 && statusCode < 400)
                {
                    return true;
                }
                else if (statusCode >= 500 && statusCode <= 510)
                {
                    System.Console.WriteLine("The remote server has thrown an internal error. Url is not valid: {0}");
                    return false;
                }
            }
            catch (WebException ex)
            {
                if (ex.Status == WebExceptionStatus.ProtocolError)
                {
                    return false;
                }
                else
                {
                    System.Console.WriteLine("Unhandled status [{0}] returned for url: {1}");
                }
            }
            catch (Exception ex)
            {
                System.Console.WriteLine("Could not test url {0}.");
            }
            return false;
        }
    }

}
