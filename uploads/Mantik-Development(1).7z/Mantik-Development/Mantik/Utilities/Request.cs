﻿using System;
using UnityEngine;
using Newtonsoft.Json;
using System.Net;
using System.Collections.Generic;
using System.IO;
using Mantik.Model;
using System.Xml;
using Newtonsoft.Json.Linq;

namespace Mantik.Utilities
{
    class Request
    {
        private static Request request;

        private string host;

        private Request()
        {
            XmlDocument xml = new XmlDocument();

            xml.Load(Application.streamingAssetsPath + "/host.xml");
            XmlNodeList list = xml.GetElementsByTagName("host");
            XmlElement node = (XmlElement)list[0];
            host = node.GetAttribute("hostIp");
           

        }

        public static Request getInstance()
        {
            if (request == null)
            {
                request = new Request();
            }
            return request;
        }

        public T post<T>(string uri, T data)
        {
            string response;
            T result;


            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(host + uri);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            try
            {
                StreamWriter PostData = new StreamWriter(httpWebRequest.GetRequestStream());
                PostData.Write(JsonConvert.SerializeObject(data));
                PostData.Flush();
                PostData.Close();

                HttpWebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                StreamReader answer = new StreamReader(httpResponse.GetResponseStream());
                response = answer.ReadToEnd();

                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("url:" + host + uri);
                System.Console.WriteLine("statusCode:" + httpResponse.StatusCode);
                System.Console.WriteLine("respuesta " + response);
                System.Console.WriteLine("----------------------------");
                result = JsonConvert.DeserializeObject<T>(response);

            }
            catch (WebException e)
            {
                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("WebException e: " + e.Message);
                System.Console.WriteLine("----------------------------");
                throw new Exception(e.Message + " url:" + host + uri);
            }
            return result;
        }


        public List<T> getserviceList<T>(string uri)
        {
            string response;
            List<T> result = null;

            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(host + uri);
            httpWebRequest.Method = "GET";
            try
            {
                HttpWebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                StreamReader answer = new StreamReader(httpResponse.GetResponseStream());
                response = answer.ReadToEnd();
                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("url:" + host + uri);
                System.Console.WriteLine("statusCode:" + httpResponse.StatusCode);
                System.Console.WriteLine("respuesta " + response);
                System.Console.WriteLine("----------------------------");
                result = JsonConvert.DeserializeObject<List<T>>(response);

            }
            catch (WebException e)
            {
                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("WebException e: " + e.Message);
                System.Console.WriteLine("----------------------------");
                throw new Exception(e.Message + " url:" + host + uri);
            }
            return result;
        }

        public T getservice<T>(string uri)
        {
            string response;
            T result;

            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(host + uri);
            httpWebRequest.Method = "GET";
            try
            {
                HttpWebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                StreamReader answer = new StreamReader(httpResponse.GetResponseStream());
                response = answer.ReadToEnd();
                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("url:" + host + uri);
                System.Console.WriteLine("statusCode:" + httpResponse.StatusCode);
                System.Console.WriteLine("respuesta " + response);
                System.Console.WriteLine("----------------------------");
                result = JsonConvert.DeserializeObject<T>(response);

            }
            catch (WebException e)
            {
                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("WebException e: " + e.Message);
                System.Console.WriteLine("----------------------------");
                throw new Exception(e.Message + " url:" + host + uri);
            }
            return result;
        }
        //------------------------------------------------------------------------------------
        public Dictionary<string, object> getservice(string uri)
        {
            string response;
            Dictionary<string, object> result;

            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(host + uri);
            httpWebRequest.Method = "GET";
            try
            {
                HttpWebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                StreamReader answer = new StreamReader(httpResponse.GetResponseStream());
                response = answer.ReadToEnd();
                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("url:" + host + uri);
                System.Console.WriteLine("statusCode:" + httpResponse.StatusCode);
                System.Console.WriteLine("respuesta " + response);
                System.Console.WriteLine("----------------------------");
                result = JsonConvert.DeserializeObject<Dictionary<string, object>>(response.Trim('[', ']'));
            }
            catch (WebException e)
            {
                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("WebException e: " + e.Message);
                System.Console.WriteLine("----------------------------");
                throw new Exception(e.Message + " url:" + host + uri);
            }
            return result;
        }
        //------------------------------------------------------------------------------------
        public T put<T>(string uri, T data)
        {
            string response;
            T result;


            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(host + uri);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "PUT";
            try
            {
                StreamWriter PostData = new StreamWriter(httpWebRequest.GetRequestStream());
                PostData.Write(JsonConvert.SerializeObject(data));
                PostData.Flush();
                PostData.Close();

                HttpWebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

                StreamReader answer = new StreamReader(httpResponse.GetResponseStream());
                response = answer.ReadToEnd();

                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("url:" + host + uri);
                System.Console.WriteLine("statusCode:" + httpResponse.StatusCode);
                System.Console.WriteLine("respuesta " + response);
                System.Console.WriteLine("----------------------------");
                result = JsonConvert.DeserializeObject<T>(response);

            }
            catch (WebException e)
            {
                System.Console.WriteLine("----------------------------");
                System.Console.WriteLine("WebException e: " + e.Message);
                System.Console.WriteLine("----------------------------");
                throw new Exception(e.Message + " url:" + host + uri);
            }
            return result;
        }

        public string getHost()
        {
            return host;
        }
    }
}