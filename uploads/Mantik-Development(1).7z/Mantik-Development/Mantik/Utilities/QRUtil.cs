﻿using System;
using com.google.zxing;
using com.google.zxing.qrcode;

namespace Mantik.Utilities
{
    class QRUtil
    {
        private Result stringQR;
        private static QRUtil instance = null;

        public QRUtil()
        {
        }

        public static QRUtil getInstance()
        {
            if (instance == null)
            {
                instance = new QRUtil();
            }
            return instance;
        }

        public string DecodeQR(sbyte[] d, int width, int height)
        {
            stringQR = new QRCodeReader().decode(d, width, height);
            return stringQR.Text;
        }
    }
}
