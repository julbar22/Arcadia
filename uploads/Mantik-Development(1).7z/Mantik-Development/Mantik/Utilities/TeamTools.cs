﻿using Mantik.Handler;
using Mantik.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Utilities
{
    public class TeamTools
    {
        private EntityHandler handler;

        public TeamTools()
        {
            handler = new EntityHandler();
        }

        public void UpdateCoordinate(string id, Location location, Rotation rotation)
        {
            Entity entity = (Entity)handler.getByID(id);
            entity.location = location;
            entity.rotation = rotation;
            handler.UploadEntity(entity);
        }
    }
}
