﻿using Mantik.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Handler
{
    class ReportHandler : Handler
    {
        public ReportHandler() : base()
        {
        }

        public override Element getByID(string id)
        {
            return null;
        }

        public Report[] getAllReportByEntity(string entityId)
        {
            try
            {
                return request.getserviceList<Report>("/customerData/reports/" + entityId).ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }



        public override Element[] findAll()
        {
            return null;
        }

    }
}

