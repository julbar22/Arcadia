﻿using System;
using Mantik.Model;

namespace Mantik.Handler
{
    class AttributeHandler : Handler
    {
        public AttributeHandler():base()
        {
        }

        public override Element getByID(string id)
        {
            try
            {
                return request.getservice<AttributeModel>("/attributes/" + id);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public override Element[] findAll()
        {            
            try
            {
                return request.getserviceList<AttributeModel>("/attributes/").ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public Element[] getAttributesByEntityId(string id)
        {            
            try
            {
                return request.getserviceList<AttributeModel>("/attributes/entities/" + id).ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public AttributeModel[] getAttributes(string id)
        {
            return request.getserviceList<AttributeModel>("/attributes/" + id).ToArray();
        }

    }
}
