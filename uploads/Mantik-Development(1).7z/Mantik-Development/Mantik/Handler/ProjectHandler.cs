﻿using System;
using Mantik.Model;

namespace Mantik.Handler
{
    class ProjectHandler : Handler
    {
        public ProjectHandler():base()
        {
        }

        public override Element getByID(string id)
        {
            try
            {
                return request.getservice<Project>("/customerData/projects/" + id);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public override Element[] findAll()
        {            
            try
            {
                return request.getserviceList<Project>("/customerData/projects/").ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

    }
}
