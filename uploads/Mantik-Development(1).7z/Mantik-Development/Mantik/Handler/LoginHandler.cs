﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mantik.Model;

namespace Mantik.Handler
{
    class LoginHandler : Handler
    {
        public override Element[] findAll()
        {
            throw new NotImplementedException();
        }

        public override Element getByID(string id)
        {
            throw new NotImplementedException();
        }

        public Element loginRequest(string user, string password)
        {
            try
            {
                return request.post<User>("/user/logIn/", new User { user = user, password = password });

            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
