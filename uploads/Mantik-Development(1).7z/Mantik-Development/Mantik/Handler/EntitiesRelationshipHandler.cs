﻿using System;
using Mantik.Model;
using System.Collections.Generic;

namespace Mantik.Handler
{
    class EntitiesRelationshipHandler : Handler
    {
        public EntitiesRelationshipHandler() : base()
        {
        }

        public override Element getByID(string id)
        {
            try
            {
                return request.getservice<EntitiesRelationship>("/customerData/entitiesRelationship/" + id); //url
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }


        public override Element[] findAll()
        {
            return request.getserviceList<EntitiesRelationship>("/customerData/entitiesRelationship/").ToArray();
        }

        public Element[] getSonsByRelationFatherId(string id)  //trae las relaciones hijas o puede traer la entidades de esos niveles
        {         
            return request.getserviceList<Entity>("/customerData/entitiesRelationship/sons/" + id).ToArray();
        }

        public Element[] getSonsByRelationEntity(string entityId)  //no estoy seguro entidades segun una entidad en una relacion superior
        {
            return request.getserviceList<Entity>("/customerData/entitiesRelationship/sons/memberId" + entityId).ToArray();
        }

        public Element[] hierarchyRelationship(string id)  //trae las relaciones o entidades de la relacion raiz
        {
            return request.getserviceList<Entity>("/customerData/entitiesRelationship/all/" + id).ToArray();
        }


        public EntitiesRelationship UploadEntity(EntitiesRelationship entityRelationship)
        {
            try
            {
                return request.put("/customerData/entitiesRelationship/" + entityRelationship._id, entityRelationship);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
