﻿using System;
using Mantik.Model;

namespace Mantik.Handler
{
    class DocumentsCategoryHandler : Handler
    {
        public DocumentsCategoryHandler():base()
        {
        }

        public override Element getByID(string id)
        {
            try
            {
                return request.getservice<DocumentsCategory>("/documentation/category/" + id);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public override Element[] findAll()
        {
            try
            {
                return request.getserviceList<DocumentsCategory>("/documentation/category/").ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }            
        }

        public Element[] getByEntityIdAndType(string entityId, string flagType)
        {
            try
            {
                return request.getserviceList<DocumentsCategory>("/documentation/category/entity/" + entityId + "/" + flagType).ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            
        }    
    }
}
