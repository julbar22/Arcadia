﻿using Mantik.Logic.Login;
using Mantik.Logic.QRModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mantik.Handler
{
    class ModuleHandler
    {
        private List<Module> modules;

        public ModuleHandler()
        {
            modules = new List<Module>();
        }

        public List<Module> getModulesByIDUser(int idUser)
        {
            addReports();
            addDocumentLibrary();
            addQR();
            addQRManual();
            addDashboard();
            addMantenimientos();
            //addLevelPlane();
            return modules;
        }

        private void addQR()
        {
            List<Menu> menus = new List<Menu>();
            menus.Add(new Menu("Manual"));
            menus.Add(new Menu("Camera"));
            Module qrModule = new Module("QR", true, "centerLinePanel", menus);
            modules.Add(qrModule);
        }

        private void addReports()
        {
            Module reports = new Module("Reports", true, "leftLinePanel");
            modules.Add(reports);
        }

        private void addDocumentLibrary()
        {
            Module documentLibrary = new Module("DocumentLibrary", true, "leftLinePanel");
            modules.Add(documentLibrary);
        }

        private void addDashboard()
        {
            Module dashboard = new Module("Dashboard", false, "rigthLinePanel");
            modules.Add(dashboard);
        }


        private void addQRManual()
        {
            Module qrManual = new Module("QRManual", true, "centerLinePanel");
            modules.Add(qrManual);
        }

        private void addLevelPlane()
        {
             Module levelPlane = new Module("LevelPlane", true, "centerLinePanel");
             modules.Add(levelPlane);
        }

        private void addMantenimientos()
        {
            Module mantenimientos = new Module("Mantenimientos", true, "centerLinePanel");
            modules.Add(mantenimientos);
        }
    }
}
