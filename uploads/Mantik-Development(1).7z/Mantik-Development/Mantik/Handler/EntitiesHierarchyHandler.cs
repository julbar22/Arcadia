﻿using System;
using Mantik.Model;
using System.Collections.Generic;

namespace Mantik.Handler
{
    class EntitiesHierarchyHandler : Handler
    {
        public EntitiesHierarchyHandler() : base()
        {
        }

        public override Element getByID(string id)
        {
            try
            {
                return request.getservice<EntitiesHierarchy>("/customerData/entitiesHierarchy/" + id);//posible url
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
        


        public override Element[] findAll()
        {
            return request.getserviceList<EntitiesHierarchy>("/customerData/entitiesHierarchy/").ToArray();
        }
        

        public EntitiesHierarchy UploadEntity(EntitiesHierarchy entityHierarchy)
        {
            try
            {
                return request.put("/customerData/entitiesHierarchy/" + entityHierarchy._id, entityHierarchy);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
