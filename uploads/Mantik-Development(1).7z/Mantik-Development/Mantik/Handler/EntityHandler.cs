﻿using System;
using Mantik.Model;
using System.Collections.Generic;

namespace Mantik.Handler
{
    class EntityHandler : Handler
    {
        public EntityHandler() : base()
        {
        }

        public override Element getByID(string id)
        {
            try
            {
                return request.getservice<Entity>("/customerData/entities/" + id);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public List<Entity> getByName(string name)
        {
            try
            {
                return request.getserviceList<Entity>("/customerData/entity/qr/" + name);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }


        public override Element[] findAll()
        {
            return request.getserviceList<Entity>("/customerData/entities/").ToArray();
        }

       public Element[] getSonsByEntityFatherId(string id, bool systemRequired)
        {
            string flag = systemRequired == false ? "0" : "1";
            return request.getserviceList<Entity>("/customerData/entities/sons/" + id + "/" + flag).ToArray();
        }

        public Dictionary<string, object> getEntityById(string id)
        {
            try
            {
                return request.getservice("/customerData/entities/" + id);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public Entity UploadEntity(Entity entity)
        {
            try
            {
                return request.put("/customerData/entities/" + entity._id, entity);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
