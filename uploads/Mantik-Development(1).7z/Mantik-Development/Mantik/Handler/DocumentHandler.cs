﻿using System;
using Mantik.Model;
using System.Collections.Generic;

namespace Mantik.Handler
{
    class DocumentHandler : Handler
    {
        public DocumentHandler():base()
        {
        }

        public override Element getByID(string id)
        {
            try
            {
                return request.getservice<Document>("/documentation/documents/" + id);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public override Element[] findAll()
        {            
            try
            {
                return request.getserviceList<Document>("/documents/").ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public Element[] getDocumentsByCategoryIdAndEntityId(string categoryId, string entityId, string flagEnityType)
        {
            try
            {
                return request.getserviceList<Document>("/documentation/entities/group/" + categoryId + "/" + entityId + "/" + flagEnityType).ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public Element[] getByFolderFatherIdAndEntityId(string folderFatherID, string entityId, string flagEnityType)
        {
            try
            {
                return request.getserviceList<Document>("/documentation/documents/folderFather/" + folderFatherID + "/entity/" + entityId + "/type/" + flagEnityType).ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        //public Element[] getByFolderFatherId(string folderFatherID)
        //{            
        //    //Element[] documents = new Element[1];
        //    //Document documento = new Document();
        //    //documento._id = "3";
        //    //documento.name = "TestFolderEspecial";
        //    //documento.folderFatherId = "15";
        //    //documents[0] = documento;
        //    //return documents;
        //    try
        //    {
        //        return request.getserviceList<Document>("/documentation/documents/folderFather/" + folderFatherID).ToArray();
        //    }
        //    catch (Exception e)
        //    {
        //        throw new Exception(e.Message);
        //    }
        //}

        public string getUrlByDocumentId(string id)
        {
            Dictionary<string, object> result;
            try
            {
                result = request.getservice("/documentation/mongo/" + id);
                return request.getHost() + result["url"].ToString();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
