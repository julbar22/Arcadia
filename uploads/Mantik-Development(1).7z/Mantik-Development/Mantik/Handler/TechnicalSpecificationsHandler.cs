﻿using System;
using Mantik.Model;
using System.Collections.Generic;

namespace Mantik.Handler
{
    class TechnicalSpecificationsHandler : Handler
    {
        public TechnicalSpecificationsHandler() : base()
        {
        }

        public override Element[] findAll()
        {
           return null;
        }

        public override Element getByID(string id)
        {
            return null;
        }

        public Dictionary<string, object> getByEntityID(string id)
        {
            try
            {
                return request.getservice("/customerData/entity/techSpecifications/" + id);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
