﻿using System;
using Mantik.Utilities;
using Mantik.Model;

using Newtonsoft.Json;
using System.Net;
using System.Collections.Generic;
using System.IO;

namespace Mantik.Handler
{
    abstract class Handler
    {

        protected Request request;
        public Handler()
        {
            request = Request.getInstance();
        }

        public abstract Element getByID(string id);

        public abstract Element[] findAll();
    }
}
