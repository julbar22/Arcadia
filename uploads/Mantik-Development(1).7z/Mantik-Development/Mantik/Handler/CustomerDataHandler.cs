﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mantik.Model;

namespace Mantik.Handler
{
    class CustomerDataHandler : Handler
    {
        public override Element[] findAll()
        {
            throw new NotImplementedException();
        }

        public override Element getByID(string id)
        {
            throw new NotImplementedException();
        }

        public Category[] getCategories()
        {
            return request.getserviceList<Category>("/category").ToArray();
        }

        public Category[] getAttributes(string id)
        {
            return request.getserviceList<Category>("/attributes/entities/" + id).ToArray();
        }

        public AttributeCategories[] getAttributeCategories(string id)
        {
            return request.getserviceList<AttributeCategories>("/attributeCategories/" + id).ToArray();
        }
    }
}
