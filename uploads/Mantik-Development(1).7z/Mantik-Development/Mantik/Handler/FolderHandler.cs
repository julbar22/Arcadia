﻿using System;
using Mantik.Model;

namespace Mantik.Handler
{
    class FolderHandler : Handler
    {
        public FolderHandler():base()
        {
        }

        public override Element getByID(string id)
        {
            try
            {
                return request.getservice<Folder>("/documentation/folder/" + id);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public override Element[] findAll()
        {            
            try
            {
                return request.getserviceList<Folder>("/documentation/folder").ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
        
        public Element[] getByFolderFatherIdAndEnityId(string folderFatherID, string entityID, string flagEntityType)
        {            
            try
            {
                return request.getserviceList<Folder>("/documentation/folder/folderFather/" + folderFatherID + "/entity/" + entityID + "/type/" + flagEntityType).ToArray();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }   
        
        //public Element[] getByFolderFatherId(string folderFatherID)
        //{      
        //    try
        //    {
        //        return request.getserviceList<Folder>("/documentation/folder/folderFather/" + folderFatherID).ToArray();
        //    }
        //    catch (Exception e)
        //    {
        //        throw new Exception(e.Message);
        //    }
        //}
    }
}
