﻿using Mantik.Model;
using System;
using System.Collections.Generic;

namespace Mantik.Handler
{
    class NotificationHandler : Handler
    {
        public NotificationHandler() : base()
        {
        }

        public Element getByUserId(string userId, string id)
        {
            try
            {
                return request.getservice<Notification>("/user/notifications/" + userId + "/" + id);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }

        }

        public List<Notification> getAllByUserId(string userId)
        {
            try
            {
                return request.getserviceList<Notification>("/user/notifications/" + userId);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public Notification postChangeACK( string notificationId, Notification info)
        {
            try
            {
                return request.post<Notification>("/user/notifications/" + notificationId, info);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public override Element getByID(string id)
        {
            return null;
        }

        public override Element[] findAll()
        {
            return null;
        }

    }
}
